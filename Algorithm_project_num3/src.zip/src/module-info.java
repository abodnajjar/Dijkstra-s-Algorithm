module Algorithm_project_num3 {
	requires javafx.controls;
	
	opens application to javafx.graphics, javafx.fxml;
}
